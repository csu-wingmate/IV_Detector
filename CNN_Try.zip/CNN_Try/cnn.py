import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import numpy as np
import pandas as pd
import tensorflow as tf
from keras import layers, models
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. 加载CSV文件数据
# 假设CSV文件名为"data.csv"
df = pd.read_csv('dataset.csv', header=0)

# 2. 提取电流、 电压和标签
# 前两行是电流和电压，第三行是标签
X = df.iloc[0:2, :].T.values  # 电流和电压作为输入特征，转置以便每列作为一个样本
y = df.iloc[2, :].values  # 标签是第三行数据
# 检查标签的最大值
print(np.max(y))  # 输出标签中最大值，确保它小于类别数

# 3. 数据预处理
# 这里使用StandardScaler对电流和电压进行标准化，使数据分布更适合训练
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 4. 将标签转换为one-hot编码
y = to_categorical(y, num_classes=5)


# 5. 将数据集随机分成训练集和测试集（80%训练集，20%测试集）
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. 使用tf.reshape()调整数据形状
# CNN的输入要求是4维数据，[样本数, 高度, 宽度, 通道数]
X_train = tf.reshape(X_train, (X_train.shape[0], 2, 1, 1))  # 2个特征，1个通道
X_test = tf.reshape(X_test, (X_test.shape[0], 2, 1, 1))

# 7. 构建CNN模型
model = models.Sequential()

# 8. 添加卷积层，使用1x1的卷积核，因为我们的输入是二维数据（电流和电压）
model.add(layers.Conv2D(32, (1, 1), activation='relu', input_shape=(2, 1, 1)))

# 9. 添加最大池化层
model.add(layers.MaxPooling2D((1, 1)))

# 10. 扁平化层：将数据从二维展平为一维
model.add(layers.Flatten())

# 11. 全连接层，128个神经元，激活函数ReLU
model.add(layers.Dense(128, activation='relu'))

# 12. 输出层，5个神经元，softmax激活函数用于分类（标签从0到4）
model.add(layers.Dense(5, activation='softmax'))

# 13. 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# 14. 训练模型
model.fit(X_train, y_train, epochs=10, batch_size=64, validation_data=(X_test, y_test))

# 15. 评估模型在测试集上的表现
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=2)
print(f"Test accuracy: {test_acc}")

# 16. 输出每个标签的预测
y_pred = model.predict(X_test)
y_pred_labels = np.argmax(y_pred, axis=1)  # 获取最大概率对应的标签

# 输出预测结果与真实标签
print("\nPredictions vs True Labels:")
for i in range(10):  # 显示前10个预测结果
    print(f"Predicted: {y_pred_labels[i]}, True: {np.argmax(y_test[i])}")
