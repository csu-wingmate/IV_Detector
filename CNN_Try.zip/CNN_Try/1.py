import pandas as pd
import numpy as np
import torch

# 读取 CSV 文件，替换 'your_file_path.csv' 为你的文件路径
file_path = 'dataset.csv'
data = pd.read_csv(file_path)

# 初始化一个列表用于存储每一组的 NumPy 数组
numpy_array_list = []

# 遍历数据，每两行获取一组电压和电流数据
for i in range(0, len(data), 2):
    if i + 1 < len(data):
        voltage_row = data.iloc[i, 5:].values  # 提取电压值
        current_row = data.iloc[i + 1, 5:].values  # 提取电流值

        # 创建一个 2x256 的 NumPy 数组
        numpy_array = np.array([voltage_row, current_row], dtype=np.float32)
        numpy_array_list.append(numpy_array)

# 将所有的 NumPy 数组堆叠成一个大的数组
final_numpy_array = np.stack(numpy_array_list)

# 将 NumPy 数组转换为 PyTorch tensor
final_tensor = torch.tensor(final_numpy_array, dtype=torch.float32)

# 打印 tensor 的形状以确认
print(f'Tensor shape: {final_tensor.shape}')
print(final_tensor)

# 将 tensor 重新整形为 (n, 2, 16, 16) 的格式，其中 n 是数据组数量
reshaped_tensor = final_tensor.view(-1, 2, 16, 16)

# 对每组数据在第0维度(电压和电流)上进行归一化，使其在 [0, 1] 范围内
min_values = reshaped_tensor.min(dim=2, keepdim=True)[0].min(dim=3, keepdim=True)[0]
max_values = reshaped_tensor.max(dim=2, keepdim=True)[0].max(dim=3, keepdim=True)[0]
normalized_tensor = (reshaped_tensor - min_values) / (max_values - min_values)

# 打印最终 tensor 的形状以确认
print(f'Normalized tensor shape: {normalized_tensor.shape}')