import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# 读取CSV文件并加载数据
data = pd.read_csv('IV扫描数据-20240905.csv')

# 移除无关的列
data = data.drop(columns=['组别', '组串号', 'DateID', '数据项'], errors='ignore')

# 提取标签和特征
labels = data['label']
features = data.drop(columns=['label'])

# 根据顺序手动划分数据集为训练集和测试集（按顺序选取）
split_index = int(len(features) * 0.7)  # 70% 用于训练，30% 用于测试

# 划分训练集和测试集
X_train = features.iloc[:split_index]
X_test = features.iloc[split_index:]
y_train = labels.iloc[:split_index]
y_test = labels.iloc[split_index:]

# 特征缩放（标准化）
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 创建并训练随机森林模型
random_forest_model = RandomForestClassifier(n_estimators=100, random_state=42)
random_forest_model.fit(X_train, y_train)

# 预测测试数据
y_pred = random_forest_model.predict(X_test)

# 计算准确度
accuracy = accuracy_score(y_test, y_pred)

# 生成混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)

# 打印分类报告
class_report = classification_report(y_test, y_pred)

# 打印模型评估结果
print(f"Accuracy: {accuracy:.2f}")
print(f"Confusion Matrix:\n{conf_matrix}")
print(f"Classification Report:\n{class_report}")
