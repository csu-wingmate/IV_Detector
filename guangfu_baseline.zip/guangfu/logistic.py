import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# 读取CSV文件并加载数据
data = pd.read_csv('IV扫描数据-20240905.csv')

# 移除无关的列
data = data.drop(columns=['组别', '组串号', 'DateID', '数据项'], errors='ignore')

# 提取标签和特征
labels = data['label']
features = data.drop(columns=['label'])

# 划分数据集为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.8, random_state=42)

# 特征缩放（标准化）
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 创建并训练逻辑回归模型
logistic_model = LogisticRegression(solver='liblinear', max_iter=20000, random_state=42)
logistic_model.fit(X_train, y_train)

# 预测测试数据
y_pred = logistic_model.predict(X_test)

# 计算准确度
accuracy = accuracy_score(y_test, y_pred)

# 生成混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)

# 打印分类报告
class_report = classification_report(y_test, y_pred)

# 打印模型评估结果
print(f"Accuracy: {accuracy:.2f}")
print(f"Confusion Matrix:\n{conf_matrix}")
print(f"Classification Report:\n{class_report}")
